# MyAI v2 — local ChatGPT-style application

React + Vite frontend, Express backend, PostgreSQL persistence, and an OpenAI-compatible FreeLLMAPI gateway.

## Features
- Local account registration/login with PostgreSQL-backed sessions
- Persistent conversations and messages
- Auto routing (`auto`) plus manual model selection
- Server-sent streaming responses
- Stop generation and regenerate last answer
- Upload PNG/JPEG/WebP/GIF images, PDF, TXT, Markdown and DOCX
- Image input is sent as an OpenAI-compatible image URL; documents are text-extracted
- Markdown, GFM tables and syntax-highlighted code blocks
- Dark/light theme

## Requirements
- Node.js 20+
- Docker Desktop (or a PostgreSQL 16 instance)
- FreeLLMAPI running locally at `http://127.0.0.1:3001/v1`

## Setup

1. Start PostgreSQL:

   ```bash
   docker compose up -d db
   ```

2. Configure backend environment:

   ```bash
   cp server/.env.example server/.env
   ```

   Set `SESSION_SECRET` to a random string of 32+ characters and set `LLM_API_KEY` to your FreeLLMAPI unified key. Verify `LLM_BASE_URL` and `LLM_DEFAULT_MODEL` against your FreeLLMAPI configuration. If the gateway doesn't support a model named `auto`, set a valid default model or configure its routing alias.

3. Install dependencies and migrate:

   ```bash
   npm install
   npm run migrate -w server
   ```

4. Start the app in development:

   ```bash
   npm run dev
   ```

5. Open http://127.0.0.1:5173 and create your local account.

## Production build (still local)

```bash
npm run build
npm start
```

Then open http://127.0.0.1:4000. The Express process serves `client/dist`.

## Important operational notes

- The server binds to `127.0.0.1` intentionally. Do not expose this development-oriented single-machine setup to a network.
- Set a strong `SESSION_SECRET`; never commit `.env`.
- Uploads are stored under `server/uploads` by default. Back up or delete this folder alongside PostgreSQL data.
- The database stores message text and attachment metadata. Uploaded binary files remain on disk.
- Add a scheduled cleanup policy for orphaned uploads before long-term use.
- Add TLS, CSRF protection, hardened account recovery, audit logging, backups, and a deployment-specific security review before exposing this to other users.
- FreeLLMAPI/provider compatibility varies. Confirm the gateway's model names, `auto` routing alias, streaming support, and multimodal support. If `auto` isn't a valid model alias in your gateway, configure `LLM_DEFAULT_MODEL` to an actual supported model or routing alias.
- Some provider APIs may not support image inputs or every file type. Document extraction occurs locally for PDF, DOCX, TXT and Markdown.
- The included upload endpoint allows up to five files, each up to `MAX_UPLOAD_MB`. Adjust limits deliberately.
- For a trusted local app, account registration is open to anyone with access to the local UI. Keep the service bound to localhost and do not port-forward it.

## API overview
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/models`
- `GET|POST /api/conversations`
- `GET /api/conversations/:id/messages`
- `PATCH|DELETE /api/conversations/:id`
- `POST /api/uploads`
- `POST /api/chat` (SSE)
- `POST /api/conversations/:id/stop`
- `POST /api/conversations/:id/regenerate` (SSE)
