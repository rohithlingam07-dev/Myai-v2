import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import {
  Bot, Plus, Send, Square, Paperclip, Sun, Moon, Trash2,
  PanelLeftClose, PanelLeftOpen, RefreshCw, LogOut, MessageSquare,
  X, FileText, Image as ImageIcon, LoaderCircle, Menu
} from "lucide-react";

const api = async (url, options = {}) => {
  const response = await fetch(url, { credentials: "same-origin", ...options });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  if (response.status === 204) return null;
  return response.json();
};

function Auth({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const data = await api(`/api/auth/${mode}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      onLogin(data.user);
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  return <main className="auth-shell"><form className="auth-card" onSubmit={submit}>
    <div className="brand-mark"><Bot size={28}/></div>
    <h1>{mode === "login" ? "Welcome back" : "Create your MyAI account"}</h1>
    <p className="muted">Your private, local AI workspace.</p>
    <label>Email<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label>
    <label>Password<input type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={10} required value={password} onChange={e=>setPassword(e.target.value)}/></label>
    {error && <div className="error">{error}</div>}
    <button className="primary full" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
    <button type="button" className="text-button" onClick={()=>{setMode(mode==="login"?"register":"login");setError("");}}>
      {mode === "login" ? "Create a local account" : "I already have an account"}
    </button>
    <small className="muted">Use a strong, unique password. Accounts are stored in your local PostgreSQL database.</small>
  </form></main>;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [models, setModels] = useState(["auto"]);
  const [model, setModel] = useState("auto");
  const [draft, setDraft] = useState("");
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [dark, setDark] = useState(localStorage.getItem("myai-theme") !== "light");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenu, setMobileMenu] = useState(false);
  const controllerRef = useRef(null);
  const fileRef = useRef(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    api("/api/auth/me").then(d=>setUser(d.user)).catch(()=>{}).finally(()=>setChecking(false));
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    localStorage.setItem("myai-theme", dark ? "dark" : "light");
  }, [dark]);
  const refreshConversations = useCallback(async () => {
    const data = await api("/api/conversations");
    setConversations(data.conversations);
  }, []);
  useEffect(() => {
    if (!user) return;
    refreshConversations().catch(e=>setError(e.message));
    api("/api/models").then(d=>{
      const ids = d.models.map(m=>m.id);
      setModels(["auto", ...ids.filter(id=>id!=="auto")]);
    }).catch(e=>setError(e.message));
  }, [user, refreshConversations]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  async function createConversation() {
    const data = await api("/api/conversations", { method: "POST" });
    setActiveId(data.conversation.id); setMessages([]); setModel("auto"); setError("");
    await refreshConversations();
  }
  async function openConversation(id) {
    if (busy) return;
    setActiveId(id); setError("");
    const data = await api(`/api/conversations/${id}/messages`);
    setMessages(data.messages); 
    const c = conversations.find(x=>x.id===id);
    setModel(c?.model || "auto");
    setMobileMenu(false);
  }
  async function deleteConversation(id) {
    if (!confirm("Delete this conversation permanently?")) return;
    await api(`/api/conversations/${id}`, { method: "DELETE" });
    if (activeId === id) { setActiveId(null); setMessages([]); }
    await refreshConversations();
  }
  async function uploadSelected(fileList) {
    const selected = Array.from(fileList || []);
    if (!selected.length) return;
    setUploading(true); setError("");
    try {
      const form = new FormData();
      selected.forEach(f=>form.append("files", f));
      const data = await api("/api/uploads", { method: "POST", body: form });
      setFiles(old=>[...old, ...data.attachments]);
    } catch (e) { setError(e.message); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ""; }
  }
  async function consumeStream(url, body) {
    controllerRef.current = new AbortController();
    const response = await fetch(url, {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body), signal: controllerRef.current.signal
    });
    if (!response.ok) {
      const data = await response.json().catch(()=>({}));
      throw new Error(data.error || `Request failed (${response.status})`);
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "", answer = "";
    setMessages(old=>[...old, { id: crypto.randomUUID(), role: "assistant", content: "", attachments: [] }]);
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const events = buffer.split("\n\n"); buffer = events.pop() || "";
      for (const event of events) {
        const line = event.split("\n").find(x=>x.startsWith("data: "));
        if (!line) continue;
        const raw = line.slice(6);
        if (raw === "[DONE]") continue;
        const packet = JSON.parse(raw);
        if (packet.error) throw new Error(packet.error);
        answer += packet.content || "";
        setMessages(old=>old.map((m,i)=>i===old.length-1 ? {...m,content:answer} : m));
      }
    }
  }
  async function send(e) {
    e?.preventDefault();
    const content = draft.trim();
    if ((!content && !files.length) || busy) return;
    setBusy(true); setError("");
    try {
      let id = activeId;
      if (!id) {
        const created = await api("/api/conversations", { method: "POST" });
        id = created.conversation.id; setActiveId(id);
      }
      const attachments = [...files];
      setMessages(old=>[...old, {
        id: crypto.randomUUID(), role: "user", content,
        attachments: attachments.map(a=>({id:a.id,name:a.name,mimeType:a.mimeType}))
      }]);
      setDraft(""); setFiles([]);
      await consumeStream("/api/chat", {
        conversationId: id, content, model,
        attachmentIds: attachments.map(a=>a.id)
      });
      await refreshConversations();
    } catch (e) {
      if (e.name !== "AbortError") setError(e.message);
    } finally { setBusy(false); controllerRef.current = null; }
  }
  async function stop() {
    controllerRef.current?.abort();
    if (activeId) api(`/api/conversations/${activeId}/stop`, { method: "POST" }).catch(()=>{});
    setBusy(false);
  }
  async function regenerate() {
    if (!activeId || busy) return;
    setBusy(true); setError("");
    setMessages(old=>old.filter((m,i)=>!(m.role==="assistant" && i===old.length-1)));
    try {
      await consumeStream(`/api/conversations/${activeId}/regenerate`, {});
      await refreshConversations();
    } catch (e) { if (e.name !== "AbortError") setError(e.message); }
    finally { setBusy(false); controllerRef.current = null; }
  }
  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    setUser(null); setConversations([]); setMessages([]); setActiveId(null);
  }
  if (checking) return <div className="loading-screen"><LoaderCircle className="spin"/> Loading MyAI…</div>;
  if (!user) return <Auth onLogin={setUser}/>;

  return <div className="app-shell">
    <aside className={`sidebar ${sidebarOpen ? "" : "collapsed"} ${mobileMenu ? "mobile-open" : ""}`}>
      <div className="sidebar-top">
        <div className="brand"><span className="brand-mark small"><Bot size={21}/></span>{sidebarOpen && <b>MyAI</b>}</div>
        <button className="icon-btn mobile-close" onClick={()=>setMobileMenu(false)} aria-label="Close menu"><X/></button>
        <button className="icon-btn collapse-btn" onClick={()=>setSidebarOpen(v=>!v)} aria-label="Toggle sidebar">{sidebarOpen?<PanelLeftClose/>:<PanelLeftOpen/>}</button>
      </div>
      <button className="new-chat" onClick={createConversation}><Plus size={18}/>{sidebarOpen && "New chat"}</button>
      {sidebarOpen && <div className="history-label">YOUR CHATS</div>}
      <nav className="conversation-list">
        {conversations.map(c=><div key={c.id} className={`conversation ${activeId===c.id?"selected":""}`}>
          <button className="conversation-open" onClick={()=>openConversation(c.id)}><MessageSquare size={16}/><span>{c.title}</span></button>
          {sidebarOpen && <button className="icon-btn delete-chat" title="Delete chat" onClick={()=>deleteConversation(c.id)}><Trash2 size={14}/></button>}
        </div>)}
      </nav>
      <div className="sidebar-footer">
        {sidebarOpen && <div className="user-email">{user.email}</div>}
        <button className="footer-action" onClick={()=>setDark(v=>!v)}>{dark?<Sun size={17}/>:<Moon size={17}/ >}{sidebarOpen && (dark?"Light mode":"Dark mode")}</button>
        <button className="footer-action" onClick={logout}><LogOut size={17}/>{sidebarOpen && "Sign out"}</button>
      </div>
    </aside>

    <main className="main-panel">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={()=>setMobileMenu(true)} aria-label="Open menu"><Menu/></button>
        <div className="topbar-title">AI Assistant <span className="online-dot"/></div>
        <label className="model-select-label"><span>Model</span>
          <select value={model} onChange={e=>setModel(e.target.value)} disabled={busy}>
            <option value="auto">Auto routing</option>
            {models.filter(m=>m!=="auto").map(m=><option key={m} value={m}>{m}</option>)}
          </select>
        </label>
      </header>

      <section className="chat-scroll">
        {messages.length===0 ? <div className="welcome">
          <div className="welcome-icon"><Sparkles size={30}/></div>
          <h1>What can I help you with?</h1>
          <p>Ask a question, explore an idea, or work through a problem.</p>
          <div className="suggestions">
            {["Explain a complex topic simply","Help me debug some code","Summarize a document","Brainstorm a project"].map(s=><button key={s} onClick={()=>setDraft(s)}>{s}</button>)}
          </div>
        </div> : <div className="message-list">
          {messages.map((m,i)=><article className={`message-row ${m.role}`} key={m.id || i}>
            <div className="message-avatar">{m.role==="user"?<span>{user.email[0].toUpperCase()}</span>:<Bot size={19}/>}</div>
            <div className="message-body">
              <div className="message-author">{m.role==="user"?"You":"MyAI"}</div>
              {m.attachments?.length>0 && <div className="attachment-chips">{m.attachments.map(a=><span key={a.id}><FileText size={14}/>{a.name}</span>)}</div>}
              {m.role==="assistant" ? <div className="markdown"><ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeHighlight]}>{m.content || (busy?"Thinking…":"")}</ReactMarkdown></div> : <p className="user-content">{m.content}</p>}
            </div>
          </article>)}
          <div ref={bottomRef}/>
        </div>}
      </section>

      {error && <div className="error-banner"><span>{error}</span><button onClick={()=>setError("")}><X size={16}/></button></div>}
      <div className="composer-wrap">
        {files.length>0 && <div className="pending-files">{files.map(f=><span key={f.id}><FileText size={14}/>{f.name}<button onClick={()=>setFiles(old=>old.filter(x=>x.id!==f.id))}><X size={13}/></button></span>)}</div>}
        <form className="composer" onSubmit={send}>
          <input ref={fileRef} type="file" hidden multiple accept="image/png,image/jpeg,image/webp,image/gif,.pdf,.txt,.md,.docx" onChange={e=>uploadSelected(e.target.files)}/>
          <button type="button" className="attach-btn" onClick={()=>fileRef.current?.click()} disabled={busy||uploading} title="Attach files">{uploading?<LoaderCircle className="spin"/>:<Paperclip/>}</button>
          <textarea value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Message MyAI…" rows={1} disabled={busy} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}}/>
          {busy ? <button type="button" className="send-btn stop-btn" onClick={stop} title="Stop generating"><Square size={16}/></button> :
            <button type="submit" className="send-btn" disabled={!draft.trim()&&!files.length} title="Send message"><Send size={18}/></button>}
        </form>
        <div className="composer-note">MyAI can make mistakes. Check important information.</div>
      </div>
      {messages.length>0 && !busy && messages[messages.length-1]?.role==="assistant" && <button className="regenerate-btn" onClick={regenerate}><RefreshCw size={14}/> Regenerate response</button>}
    </main>
  </div>;
}
