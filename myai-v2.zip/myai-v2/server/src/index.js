import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import bcrypt from "bcryptjs";
import multer from "multer";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import mammoth from "mammoth";
import pdfParse from "pdf-parse";
import { z } from "zod";
import { pool } from "./db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 4000);
const ORIGIN = process.env.APP_ORIGIN || "http://127.0.0.1:5173";
const uploadDir = path.resolve(process.env.UPLOAD_DIR || "./uploads");
const maxUploadBytes = Number(process.env.MAX_UPLOAD_MB || 10) * 1024 * 1024;
await fs.mkdir(uploadDir, { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be set to at least 32 characters.");
}
if (!process.env.LLM_API_KEY) throw new Error("LLM_API_KEY is required.");
const llm = new OpenAI({
  apiKey: process.env.LLM_API_KEY,
  baseURL: process.env.LLM_BASE_URL || "http://127.0.0.1:3001/v1"
});

app.disable("x-powered-by");
app.use(helmet({ crossOriginResourcePolicy: { policy: "same-site" } }));
app.use(cors({ origin: ORIGIN, credentials: true }));
app.use(express.json({ limit: "2mb" }));

const PgStore = connectPgSimple(session);
app.use(session({
  store: new PgStore({
    pool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  name: "myai.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const chatLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const activeStreams = new Map();

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in." });
  next();
}
function sameOrigin(req, res, next) {
  const origin = req.get("origin");
  if (origin && origin !== ORIGIN) return res.status(403).json({ error: "Origin not allowed." });
  next();
}
app.use("/api", sameOrigin);

const authBody = z.object({
  email: z.string().email().max(254),
  password: z.string().min(10).max(128)
});

app.post("/api/auth/register", authLimiter, async (req, res) => {
  const parsed = authBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Use a valid email and a password of at least 10 characters." });
  const email = parsed.data.email.toLowerCase().trim();
  const hash = await bcrypt.hash(parsed.data.password, 12);
  try {
    const result = await pool.query(
      "INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email",
      [email, hash]
    );
    req.session.userId = result.rows[0].id;
    res.status(201).json({ user: result.rows[0] });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "An account with that email already exists." });
    throw e;
  }
});
app.post("/api/auth/login", authLimiter, async (req, res) => {
  const parsed = authBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid email or password." });
  const result = await pool.query("SELECT id,email,password_hash FROM users WHERE email=$1", [parsed.data.email.toLowerCase().trim()]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(parsed.data.password, user.password_hash))) {
    return res.status(401).json({ error: "Invalid email or password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start session." });
    req.session.userId = user.id;
    res.json({ user: { id: user.id, email: user.email } });
  });
});
app.post("/api/auth/logout", requireAuth, (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("myai.sid");
    res.status(204).end();
  });
});
app.get("/api/auth/me", requireAuth, async (req, res) => {
  const result = await pool.query("SELECT id,email FROM users WHERE id=$1", [req.session.userId]);
  if (!result.rowCount) return res.status(401).json({ error: "Session expired." });
  res.json({ user: result.rows[0] });
});

app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.get("/api/models", requireAuth, async (req, res) => {
  try {
    const result = await llm.models.list();
    res.json({ models: result.data.map(m => ({ id: m.id })), defaultModel: process.env.LLM_DEFAULT_MODEL || "auto" });
  } catch (e) {
    console.error("Model discovery:", e.message);
    res.status(502).json({ error: "Could not retrieve models from FreeLLMAPI." });
  }
});

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, _file, cb) => cb(null, `${crypto.randomUUID()}`)
});
const upload = multer({
  storage,
  limits: { fileSize: maxUploadBytes, files: 5 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/png", "image/jpeg", "image/webp", "image/gif", "application/pdf",
      "text/plain", "text/markdown", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
    cb(allowed.includes(file.mimetype) ? null : new Error("Unsupported file type."), allowed.includes(file.mimetype));
  }
});
app.post("/api/uploads", requireAuth, upload.array("files", 5), async (req, res) => {
  const saved = [];
  try {
    for (const file of req.files || []) {
      let extractedText = null;
      if (file.mimetype === "application/pdf") {
        const parsed = await pdfParse(await fs.readFile(file.path));
        extractedText = parsed.text.slice(0, 100000);
      } else if (file.mimetype === "text/plain" || file.mimetype === "text/markdown") {
        extractedText = (await fs.readFile(file.path, "utf8")).slice(0, 100000);
      } else if (file.mimetype.endsWith("wordprocessingml.document")) {
        const result = await mammoth.extractRawText({ path: file.path });
        extractedText = result.value.slice(0, 100000);
      }
      const id = crypto.randomUUID();
      await pool.query(
        `INSERT INTO uploads(id,user_id,original_name,mime_type,disk_name,extracted_text)
         VALUES($1,$2,$3,$4,$5,$6)`,
        [id, req.session.userId, file.originalname.slice(0,255), file.mimetype, path.basename(file.path), extractedText]
      );
      saved.push({ id, name: file.originalname, mimeType: file.mimetype, size: file.size });
    }
    res.status(201).json({ attachments: saved });
  } catch (e) {
    for (const f of req.files || []) await fs.unlink(f.path).catch(() => {});
    console.error("Upload processing:", e);
    res.status(400).json({ error: "Could not process one or more uploaded files." });
  }
});

app.get("/api/conversations", requireAuth, async (req, res) => {
  const result = await pool.query(
    "SELECT id,title,model,created_at,updated_at FROM conversations WHERE user_id=$1 ORDER BY updated_at DESC",
    [req.session.userId]
  );
  res.json({ conversations: result.rows });
});
app.post("/api/conversations", requireAuth, async (req, res) => {
  const id = crypto.randomUUID();
  const result = await pool.query(
    "INSERT INTO conversations(id,user_id,title,model) VALUES($1,$2,'New chat',$3) RETURNING *",
    [id, req.session.userId, process.env.LLM_DEFAULT_MODEL || "auto"]
  );
  res.status(201).json({ conversation: result.rows[0] });
});
app.get("/api/conversations/:id/messages", requireAuth, async (req, res) => {
  const owner = await pool.query("SELECT id FROM conversations WHERE id=$1 AND user_id=$2", [req.params.id, req.session.userId]);
  if (!owner.rowCount) return res.status(404).json({ error: "Conversation not found." });
  const result = await pool.query(
    "SELECT id,role,content,attachments,created_at FROM messages WHERE conversation_id=$1 ORDER BY created_at",
    [req.params.id]
  );
  res.json({ messages: result.rows });
});
app.patch("/api/conversations/:id", requireAuth, async (req, res) => {
  const title = z.string().min(1).max(100).safeParse(req.body.title);
  if (!title.success) return res.status(400).json({ error: "Invalid title." });
  const result = await pool.query(
    "UPDATE conversations SET title=$1,updated_at=NOW() WHERE id=$2 AND user_id=$3 RETURNING id,title,model",
    [title.data, req.params.id, req.session.userId]
  );
  if (!result.rowCount) return res.status(404).json({ error: "Conversation not found." });
  res.json({ conversation: result.rows[0] });
});
app.delete("/api/conversations/:id", requireAuth, async (req, res) => {
  const result = await pool.query("DELETE FROM conversations WHERE id=$1 AND user_id=$2 RETURNING id", [req.params.id, req.session.userId]);
  if (!result.rowCount) return res.status(404).json({ error: "Conversation not found." });
  res.status(204).end();
});

async function getOwnedUploads(ids, userId) {
  if (!ids?.length) return [];
  if (!Array.isArray(ids) || ids.length > 5 || ids.some(id => typeof id !== "string")) throw new Error("Invalid attachments.");
  const result = await pool.query(
    "SELECT id,original_name,mime_type,disk_name,extracted_text FROM uploads WHERE id=ANY($1::uuid[]) AND user_id=$2",
    [ids, userId]
  );
  if (result.rowCount !== ids.length) throw new Error("An attachment was not found.");
  return result.rows;
}
async function buildProviderMessages(history, attachments) {
  const mapped = history.map(m => ({ role: m.role, content: m.content }));
  if (!attachments.length) return mapped;
  const last = mapped[mapped.length - 1];
  const textDocs = attachments.filter(a => a.extracted_text).map(a => `\n\n[Document: ${a.original_name}]\n${a.extracted_text}`).join("");
  const imageParts = [];
  for (const a of attachments.filter(a => a.mime_type.startsWith("image/"))) {
    const bytes = await fs.readFile(path.join(uploadDir, a.disk_name));
    const dataUrl = `data:${a.mime_type};base64,${bytes.toString("base64")}`;
    imageParts.push({ type: "image_url", image_url: { url: dataUrl } });
  }
  last.content = [
    { type: "text", text: `${last.content}${textDocs}` },
    ...imageParts
  ];
  return mapped;
}

async function streamCompletion(req, res, conversationId, userMessage, model, regenerate = false) {
  const userId = req.session.userId;
  const owner = await pool.query("SELECT id FROM conversations WHERE id=$1 AND user_id=$2", [conversationId, userId]);
  if (!owner.rowCount) return res.status(404).json({ error: "Conversation not found." });

  const uploads = await getOwnedUploads(userMessage.attachmentIds || [], userId);
  if (!regenerate) {
    await pool.query(
      "INSERT INTO messages(id,conversation_id,role,content,attachments) VALUES($1,$2,'user',$3,$4)",
      [crypto.randomUUID(), conversationId, userMessage.content, JSON.stringify(uploads.map(a => ({ id: a.id, name: a.original_name, mimeType: a.mime_type })))]
    );
  } else {
    await pool.query(
      "DELETE FROM messages WHERE id=(SELECT id FROM messages WHERE conversation_id=$1 AND role='assistant' ORDER BY created_at DESC LIMIT 1)",
      [conversationId]
    );
  }

  const historyResult = await pool.query(
    "SELECT role,content,attachments FROM messages WHERE conversation_id=$1 ORDER BY created_at",
    [conversationId]
  );
  const history = historyResult.rows;
  if (regenerate) {
    const lastUser = history[history.length - 1];
    const ids = (lastUser?.attachments || []).map(a => a.id);
    const regenUploads = await getOwnedUploads(ids, userId);
    uploads.splice(0, uploads.length, ...regenUploads);
  }
  const providerMessages = await buildProviderMessages(history, uploads);
  const selectedModel = model || process.env.LLM_DEFAULT_MODEL || "auto";

  await pool.query(
    "UPDATE conversations SET model=$1,updated_at=NOW(),title=CASE WHEN title='New chat' THEN LEFT($2,60) ELSE title END WHERE id=$3",
    [selectedModel, history.find(m => m.role === "user")?.content || "New chat", conversationId]
  );

  const controller = new AbortController();
  activeStreams.set(`${userId}:${conversationId}`, controller);
  res.on("close", () => {
    if (!res.writableEnded) controller.abort();
  });

  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  let fullText = "";
  try {
    const stream = await llm.chat.completions.create({
      model: selectedModel,
      messages: providerMessages,
      stream: true
    }, { signal: controller.signal });

    for await (const chunk of stream) {
      const delta = chunk.choices?.[0]?.delta?.content;
      if (typeof delta === "string" && delta) {
        fullText += delta;
        res.write(`data: ${JSON.stringify({ content: delta })}\n\n`);
      }
    }
    if (fullText) {
      await pool.query(
        "INSERT INTO messages(id,conversation_id,role,content) VALUES($1,$2,'assistant',$3)",
        [crypto.randomUUID(), conversationId, fullText]
      );
    }
    if (!res.writableEnded) {
      res.write("data: [DONE]\n\n");
      res.end();
    }
  } catch (e) {
    if (e.name !== "AbortError") {
      console.error("LLM stream:", e.message);
      if (!res.writableEnded) {
        res.write(`data: ${JSON.stringify({ error: "The model request failed. Check FreeLLMAPI and the selected model." })}\n\n`);
        res.end();
      }
    }
  } finally {
    activeStreams.delete(`${userId}:${conversationId}`);
  }
}

app.post("/api/chat", requireAuth, chatLimiter, async (req, res) => {
  const schema = z.object({
    conversationId: z.string().uuid(),
    content: z.string().min(1).max(20000),
    model: z.string().min(1).max(120).regex(/^[a-zA-Z0-9._:-]+$/).optional(),
    attachmentIds: z.array(z.string().uuid()).max(5).optional()
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid chat request." });
  const key = `${req.session.userId}:${parsed.data.conversationId}`;
  if (activeStreams.has(key)) return res.status(409).json({ error: "A response is already running in this conversation." });
  try {
    await streamCompletion(req, res, parsed.data.conversationId, parsed.data, parsed.data.model);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) res.status(500).json({ error: "Could not start chat." });
  }
});
app.post("/api/conversations/:id/regenerate", requireAuth, chatLimiter, async (req, res) => {
  const key = `${req.session.userId}:${req.params.id}`;
  if (activeStreams.has(key)) return res.status(409).json({ error: "A response is already running." });
  try {
    const last = await pool.query(
      "SELECT content,attachments FROM messages WHERE conversation_id=$1 AND role='user' ORDER BY created_at DESC LIMIT 1",
      [req.params.id]
    );
    if (!last.rowCount) return res.status(400).json({ error: "Nothing to regenerate." });
    const row = last.rows[0];
    const attachmentIds = (row.attachments || []).map(a => a.id);
    const conv = await pool.query("SELECT model FROM conversations WHERE id=$1 AND user_id=$2", [req.params.id, req.session.userId]);
    if (!conv.rowCount) return res.status(404).json({ error: "Conversation not found." });
    await streamCompletion(req, res, req.params.id, { content: row.content, attachmentIds }, conv.rows[0].model, true);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) res.status(500).json({ error: "Could not regenerate response." });
  }
});
app.post("/api/conversations/:id/stop", requireAuth, (req, res) => {
  const controller = activeStreams.get(`${req.session.userId}:${req.params.id}`);
  if (controller) controller.abort();
  res.json({ stopped: Boolean(controller) });
});

// Production static serving: build the React app and serve it from this process.
const clientDist = path.resolve(__dirname, "../../client/dist");
try {
  await fs.access(clientDist);
  app.use(express.static(clientDist));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api/")) return next();
    res.sendFile(path.join(clientDist, "index.html"));
  });
} catch {}

app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(err instanceof multer.MulterError ? 400 : 500)
    .json({ error: err.message || "Internal server error." });
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`MyAI API listening on http://127.0.0.1:${PORT}`);
});
